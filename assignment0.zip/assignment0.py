def calc_volume(length:float, width:float, height:float) -> float:
    """
    Returns the volume of a rectangular prism, where length, width, and
    height all have the taditional pysical interpretation.

    Examples
    >>> calc_volume(6, 5, 7)
    210
    >>> calc_volume(1.1, 2.45, 99)
    266.805
    """
  
                
